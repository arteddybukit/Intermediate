package com.ted.submission2_intermediate.di

import android.content.Context
import com.ted.submission2_intermediate.data.StoryRepository
import com.ted.submission2_intermediate.data.database.StoryDatabase
import com.ted.submission2_intermediate.data.retrofit.ApiConfig
import com.ted.submission2_intermediate.pref.StoryReferences
import com.ted.submission2_intermediate.pref.dataStore

object Injection {
    fun provideRepository(context: Context): StoryRepository {
        val pref = StoryReferences.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService(pref)
        val database = StoryDatabase.getDatabase(context)
        return StoryRepository.getInstance(apiService, pref,database)
    }
}