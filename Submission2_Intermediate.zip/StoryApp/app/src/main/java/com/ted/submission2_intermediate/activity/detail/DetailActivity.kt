package com.ted.submission2_intermediate.activity.detail

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.ted.submission2_intermediate.data.Result
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.ted.submission2_intermediate.R
import com.ted.submission2_intermediate.activity.main.ViewModelFactory
import com.ted.submission2_intermediate.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val factory = ViewModelFactory.getInstance(this)
    private val detailViewModel by viewModels<DetailViewModel> {
        factory
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setBackgroundDrawable(ColorDrawable(getColor(R.color.blue)))


        val id = intent.getStringExtra(EXTRA_ID)

        if(id != null){
            detailViewModel.getDetailStory(id)
        }

        detailViewModel.story.observe(this){
                story ->
            when(story){
                is Result.Loading -> {
                    binding.progressBar.visibility = View.GONE
                }
                is Result.Success -> {
                    binding.apply {
                        tvDetailName.text = story.data.name
                        tvDetailDescription.text = story.data.description

                        Glide.with(this@DetailActivity)
                            .load(story.data.photoUrl)
                            .into(ivDetailPhoto)
                    }
                }
                is Result.Error -> {
                    Toast.makeText(this, story.error, Toast.LENGTH_SHORT).show()
                }

                else -> {}
            }

        }


    }

    companion object {
        const val EXTRA_ID = "extra_id"
    }
}