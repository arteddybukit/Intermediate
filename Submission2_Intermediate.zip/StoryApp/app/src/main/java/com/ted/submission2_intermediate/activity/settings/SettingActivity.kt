package com.ted.submission2_intermediate.activity.settings

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.ted.submission2_intermediate.R
import com.ted.submission2_intermediate.activity.login.LoginActivity
import com.ted.submission2_intermediate.activity.main.MainViewModel
import com.ted.submission2_intermediate.activity.main.ViewModelFactory
import com.ted.submission2_intermediate.databinding.ActivitySettingBinding

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val mainViewModel: MainViewModel by viewModels<MainViewModel> {
        factory
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.userToolbarTitle.text = getString(R.string.settings)


        binding.apply {

            val intentLogout = Intent(this@SettingActivity, LoginActivity::class.java)
            actionLogout.setOnClickListener {
                mainViewModel.logout()

                intentLogout.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intentLogout)
                finish()
            }
        }


    }
}