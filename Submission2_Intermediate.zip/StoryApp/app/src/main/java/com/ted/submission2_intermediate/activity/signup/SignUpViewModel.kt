package com.ted.submission2_intermediate.activity.signup

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ted.submission2_intermediate.data.StoryRepository
import com.ted.submission2_intermediate.response.RegisterResponse
import kotlinx.coroutines.launch
import retrofit2.HttpException
import com.ted.submission2_intermediate.data.Result

class SignUpViewModel(
    private val storyRepository: StoryRepository
):ViewModel() {
    private val _responseResult = MutableLiveData<Result<RegisterResponse>>()
    val responseResult = _responseResult

    fun submitRegister(name:String,email:String, password:String){
        viewModelScope.launch {
            try {
                _responseResult.value = Result.Loading
                val response = storyRepository.register(name,email,password)
                if (!response.error!!){
                    _responseResult.value = Result.Success(response)
                }
            }catch (e: HttpException){
                val errorBody = e.response()?.errorBody()?.string()
                _responseResult.value = Result.Error(errorBody?:e.message())
            }
        }
    }
}
