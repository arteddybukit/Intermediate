package com.ted.submission2_intermediate.activity.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.ted.submission2_intermediate.data.StoryRepository
import com.ted.submission2_intermediate.response.story.Story

class HomeViewModel(
    repository: StoryRepository,
) : ViewModel() {

    val storyList: LiveData<PagingData<Story>> =
        repository.getStories().cachedIn(viewModelScope)

}