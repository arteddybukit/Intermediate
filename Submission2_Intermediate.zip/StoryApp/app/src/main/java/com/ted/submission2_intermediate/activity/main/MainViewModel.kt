package com.ted.submission2_intermediate.activity.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.ted.submission2_intermediate.pref.StoryReferences
import kotlinx.coroutines.launch

class MainViewModel (
    private val pref: StoryReferences
): ViewModel(){

    fun getToken() = pref.getToken().asLiveData()

    fun logout(){
        viewModelScope.launch {
            pref. clearToken()
        }
    }
}