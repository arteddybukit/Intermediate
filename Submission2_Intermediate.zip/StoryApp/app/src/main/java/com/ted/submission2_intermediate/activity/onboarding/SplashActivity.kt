package com.ted.submission2_intermediate.activity.onboarding

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.ted.submission2_intermediate.R
import com.ted.submission2_intermediate.activity.home.HomeActivity
import com.ted.submission2_intermediate.activity.main.MainViewModel
import com.ted.submission2_intermediate.activity.main.ViewModelFactory

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        supportActionBar?.hide()
        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val mainViewModel: MainViewModel by viewModels<MainViewModel> {
            factory
        }

        Handler(Looper.getMainLooper()).postDelayed(
            {
                mainViewModel.getToken().observe(this){
                        token ->
                    val intentActivity = Intent(this, if (token == null) WelcomeActivity::class.java else HomeActivity::class.java)
                    startActivity(intentActivity)
                    finish()
                }

            },
            3000L
        )


    }
}